//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SuperGrid.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SUPERGTYPE                  129
#define IDD_DIALOG_SUPERGRID            130
#define IDB_HARDCORE                    131
#define IDD_DIALOG1                     131
#define IDB_FOLDERS                     131
#define IDD_INSERT                      131
#define IDC_EDIT1                       1000
#define IDC_MONTHCALENDAR1              1003
#define IDC_BUTTON_INSERT               1003
#define IDC_LIST1                       1007
#define IDC_STATIC_FRAME                1008
#define ID_TOOLS_VIEWINADIALOG          32773
#define ID_TOOLS_DELETE                 32774
#define ID_TOOLS_EXPAND                 32775
#define ID_TOOLS_COLLAPSE               32776
#define ID_TOOLS_EXPANDALL              32777
#define ID_TOOLS_SEARCH                 32779
#define ID_TOOLS_SORT                   32780
#define ID_TOOLS_UPDATESUBITEM          32781
#define ID_TOOLS_DRAGDROP               32782
#define ID_TOOLS_DELETEALL              32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        150
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
